$(function(){
    var input = document.getElementById("country");
    input.addEventListener("keyup", function(event) {
        if (event.keyCode === 13) {
        
            event.preventDefault();
           var country = $(this).val();
        
            $.ajax({

                url :"https://covid-19-coronavirus-statistics.p.rapidapi.com/v1/stats",
                data:{"country": country},
                headers:{
                    "x-rapidapi-host": "covid-19-coronavirus-statistics.p.rapidapi.com",
                    "x-rapidapi-key": "e76zfvCJ6SmshGqnVdBmGG3eEY30p1xvU8YjsnuLvWUuwyVEF9"
                },
            
                error:function(){
                    $("#result").text('Enter a valid country');
                    return;  
                },
                success:function(result){
            
                    if(result.message!="OK")
                    {
                    $("#result").text('Enter a valid country');
                return;    
                }
                    
            
                    if(result.message == "OK")
                    {
                    var data = result.data;
                    var list = data.covid19Stats;
                    var confirmed = 0
                    list.forEach(element => {
                        confirmed = confirmed + element.confirmed;
                    });

                    $("#result").text(confirmed);
                   
                    }
            
            
                }
            
            
            
               })
          }
    });

  
})